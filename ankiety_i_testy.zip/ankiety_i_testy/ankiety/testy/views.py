from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from .models import Przedmioty
from .serializers import PrzedmiotySerializer
from django.http import JsonResponse, HttpResponse
from rest_framework.parsers import JSONParser

@csrf_exempt
def Przedmioty_list(request):
    if request.method == 'GET':
        Przedmioty_v = Przedmioty.objects.all()
        serializer = PrzedmiotySerializer(Przedmioty_v, many = True)
        return JsonResponse(serializer.data, safe=False)

    elif request.method =="POST":
        data = JSONParser().parse(request)
        serializer = PrzedmiotySerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data, status=201)
        return JsonResponse(serializer.errors, status=400)

@csrf_exempt
def Przedmioty_detail(request, pk):
    try:
        Przedmioty_y= Przedmioty.objects.get(pk=pk)
    except Przedmioty.DoesNoExist:
        return HttpResponse(status=404)

    if request.method == 'GET':
        serializer = PrzedmiotySerializer(Przedmioty_y)
        return JsonResponse(serializer,data)
    elif request.method == 'PUT':
        data = JSONParser().parse(request)
        serializer = PrzedmiotySerializer(Przedmioty_y, data=data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data, status=201)
        return JsonResponse(serializer.errors, status=400)

    elif request.method == 'DELETE':
        Przedmioty_y.delete()
        return HttpResponse(status=204)

