from django.contrib import admin
from .models import Pytanie, Przedmioty
# Register your models here.

admin.site.register(Pytanie)
admin.site.register(Przedmioty)